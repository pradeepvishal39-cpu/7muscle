// ============================================
// APP.JS — Shared utilities for all pages
// 7 Muscle Fitness Studio
// ============================================

const PHONE = '916382973619';
const WHATSAPP_MSG = encodeURIComponent('Hi! I want to know more about 7 Muscle Fitness Studio memberships.');

// ============================================
// NAVBAR
// ============================================
function initNavbar() {
  const navbar = document.querySelector('.navbar');
  const hamburger = document.querySelector('.hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileClose = document.querySelector('.mobile-nav-close');
  const urgencyBar = document.querySelector('.urgency-bar');

  // Adjust navbar top based on urgency bar, smoothly as it scrolls away
  if (urgencyBar && navbar) {
    const barH = urgencyBar.offsetHeight;

    function syncNavbarTop() {
      // Navbar top smoothly follows urgency bar off screen — no gap ever
      const offset = Math.max(0, barH - window.scrollY);
      navbar.style.top = offset + 'px';

      // Add scrolled class for visual upgrade once urgency bar is gone
      if (window.scrollY >= barH) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }

    syncNavbarTop(); // Run once on load
    window.addEventListener('scroll', syncNavbarTop, { passive: true });
  } else if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  // ---- Shared open/close helpers ----
  function openMenu() {
    if (!mobileNav) return;
    // Position panel flush below where navbar currently sits
    const navBottom = navbar ? navbar.getBoundingClientRect().bottom : 60;
    mobileNav.style.top = navBottom + 'px';
    mobileNav.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    if (!mobileNav) return;
    mobileNav.classList.remove('open');
    document.body.style.overflow = '';
  }

  // ---- Hamburger: TOGGLE (open if closed, close if open) ----
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent click bubbling to document
      if (mobileNav.classList.contains('open')) {
        closeMenu();
      } else {
        openMenu();
      }
    });
  }

  // ---- Close button (✕) ----
  if (mobileClose && mobileNav) {
    mobileClose.addEventListener('click', (e) => {
      e.stopPropagation();
      closeMenu();
    });
  }

  // ---- Close when user taps backdrop (outside nav links) ----
  if (mobileNav) {
    mobileNav.addEventListener('click', (e) => {
      if (e.target === mobileNav) closeMenu();
    });
  }

  // ---- Close on Escape key ----
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileNav && mobileNav.classList.contains('open')) {
      closeMenu();
    }
  });

  // ---- Close menu when a nav link is tapped ----
  if (mobileNav) {
    mobileNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => closeMenu());
    });
  }

  // Set active nav link
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-nav a').forEach(link => {
    if (link.getAttribute('href') === path) link.classList.add('active');
  });
}

// ============================================
// SCROLL ANIMATIONS
// ============================================
function initScrollAnimations() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, i * 80);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.fade-in-up').forEach(el => observer.observe(el));
}

// ============================================
// COUNTDOWN TIMER
// ============================================
function initCountdown(targetDate) {
  const timer = document.getElementById('countdown-timer');
  if (!timer) return;

  function update() {
    const now = new Date();
    const diff = targetDate - now;
    if (diff <= 0) {
      timer.innerHTML = '<div class="countdown-unit"><div class="countdown-num">00</div><div class="countdown-label">Hours</div></div>';
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);

    const pad = n => String(n).padStart(2, '0');
    timer.innerHTML = `
      ${d > 0 ? `<div class="countdown-unit"><div class="countdown-num">${pad(d)}</div><div class="countdown-label">Days</div></div>` : ''}
      <div class="countdown-unit"><div class="countdown-num">${pad(h)}</div><div class="countdown-label">Hours</div></div>
      <div class="countdown-unit"><div class="countdown-num">${pad(m)}</div><div class="countdown-label">Mins</div></div>
      <div class="countdown-unit"><div class="countdown-num">${pad(s)}</div><div class="countdown-label">Secs</div></div>
    `;
  }
  update();
  setInterval(update, 1000);
}

// ============================================
// EXIT INTENT POPUP
// ============================================
function initExitPopup() {
  const overlay = document.getElementById('exit-popup-overlay');
  if (!overlay) return;

  let shown = sessionStorage.getItem('exitPopupShown');
  if (shown) return;

  const closeBtn = overlay.querySelector('.exit-popup-close');

  document.addEventListener('mouseleave', e => {
    if (e.clientY <= 0 && !shown) {
      overlay.classList.add('show');
      shown = true;
      sessionStorage.setItem('exitPopupShown', '1');
    }
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', () => overlay.classList.remove('show'));
  }
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('show');
  });

  // Mobile: show after 30s
  setTimeout(() => {
    if (!shown) {
      overlay.classList.add('show');
      shown = true;
      sessionStorage.setItem('exitPopupShown', '1');
    }
  }, 30000);
}

// ============================================
// WHATSAPP BUTTON
// ============================================
function initWhatsApp() {
  document.querySelectorAll('.whatsapp-btn, .whatsapp-link').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      window.open(`https://wa.me/${PHONE}?text=${WHATSAPP_MSG}`, '_blank');
    });
  });
}

// ============================================
// COUNTER ANIMATION (stats)
// ============================================
function animateCounter(el, target, duration = 1500) {
  let start = 0;
  const step = timestamp => {
    if (!start) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target);
    if (progress < 1) requestAnimationFrame(step);
    else el.textContent = target;
  };
  requestAnimationFrame(step);
}

function initCounters() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = parseInt(entry.target.dataset.target);
        if (!isNaN(target)) animateCounter(entry.target, target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-target]').forEach(el => observer.observe(el));
}

// ============================================
// BOOKING FORM
// ============================================
function initBookingForm() {
  const form = document.getElementById('booking-form');
  if (!form) return;

  form.addEventListener('submit', async e => {
    e.preventDefault();
    
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const btn = form.querySelector('[type="submit"]');
    const original = btn.textContent;
    btn.textContent = 'Booking...';
    btn.disabled = true;

    const phone = form.phone.value.trim();
    if (!/^\d{10}$/.test(phone)) {
      showToast('Please enter a valid 10-digit phone number.', 'error');
      form.phone.focus();
      btn.textContent = original;
      btn.disabled = false;
      return;
    }

    const data = {
      name: form.name.value.trim(),
      phone,
      goal: form.goal.value,
      time_slot: form.time_slot.value
    };

    try {
      await window.bookingApi.submitBooking(data);
      showToast('Free trial booked! We\'ll call you soon 💪', 'success');
      setTimeout(() => {
        const success = document.getElementById('booking-success');
        if (success) success.style.display = 'block';
        form.style.display = 'none'; // Hides the old form to make the success state prominent
      }, 200);
    } catch (err) {
      const msg = err.message || 'Please try again or call us!';
      showToast(`Booking failed: ${msg}`, 'error');
      console.error('Supabase booking error:', err);
    } finally {
      btn.textContent = original;
      btn.disabled = false;
    }
  });
}

// ============================================
// MOBILE SLIDER: INFINITE LOOP & ZOOM FOCUS
// ============================================
function initMobileSliders() {
  const sliderGrids = document.querySelectorAll('.programs-grid, .trainers-grid, .pricing-grid, .testimonials-grid, .features-grid');
  if (!sliderGrids.length) return;

  // Only apply on mobile/tablet — re-check on resize so desktop never gets slider styles
  if (window.innerWidth > 768) return;
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      sliderGrids.forEach(g => { g.scrollLeft = 0; });
    }
  }, { passive: true });

  const observerOptions = {
    root: null,
    threshold: 0.6,
    rootMargin: '0px -25% 0px -25%'
  };

  const focalObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const sisters = entry.target.parentElement.querySelectorAll('.centered');
        sisters.forEach(s => s.classList.remove('centered'));
        entry.target.classList.add('centered');
      }
    });
  }, observerOptions);

  sliderGrids.forEach(grid => {
    const originalItems = Array.from(grid.children);
    if (!originalItems.length) return;

    // Clone items for infinite loop (need enough to fill viewport width)
    const cloneCount = 3; 
    const firstClones = originalItems.slice(0, cloneCount).map(el => el.cloneNode(true));
    const lastClones = originalItems.slice(-cloneCount).map(el => el.cloneNode(true));

    // Append/Prepend clones
    lastClones.reverse().forEach(clone => {
      clone.classList.remove('fade-in-up', 'visible');
      grid.prepend(clone);
    });
    firstClones.forEach(clone => {
      clone.classList.remove('fade-in-up', 'visible');
      grid.append(clone);
    });

    // Start focal observer on all items (original + clones)
    Array.from(grid.children).forEach(item => focalObserver.observe(item));

    // Calculate jump positions
    const itemWidth = originalItems[0].offsetWidth + 16; // width + gap
    const cloneGWidth = cloneCount * itemWidth;

    // Initial scroll position to the first real item
    grid.scrollLeft = cloneGWidth;

    // Handle the infinite jump
    grid.addEventListener('scroll', () => {
      const scrollLeft = grid.scrollLeft;
      const scrollWidth = grid.scrollWidth;
      const clientWidth = grid.clientWidth;

      // Jump when reaching the cloned buffer at the ends
      if (scrollLeft <= 5) {
        // At the start clones boundary, jump to the end originals
        grid.scrollTo({ left: scrollWidth - clientWidth - cloneGWidth, behavior: 'instant' });
      } else if (scrollLeft >= scrollWidth - clientWidth - 5) {
        // At the end clones boundary, jump to the start originals
        grid.scrollTo({ left: cloneGWidth, behavior: 'instant' });
      }
    }, { passive: true });
  });
}

// ============================================
// INIT ALL
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initScrollAnimations();
  initExitPopup();
  initWhatsApp();
  initCounters();
  initBookingForm();
  initMobileSliders();

  // Fixed offer end date — same for ALL visitors (not relative to their visit time)
  // Update this date when you run a new promotion
  const OFFER_END_DATE = new Date('2025-05-15T23:59:59');
  initCountdown(OFFER_END_DATE);
});

window.showToast = window.showToast || function(msg, type) {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 100);
  setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 400); }, 4000);
};
